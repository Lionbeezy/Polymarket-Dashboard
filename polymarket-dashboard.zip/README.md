# Polymarket Trending Certainty Dashboard

A self-updating dashboard that fetches live Polymarket data every hour and publishes it to GitHub Pages — **free, no server required**.

## What it does

- Fetches the top 50 active Polymarket markets by 24h volume
- Ranks them by **directional certainty** (furthest from 50/50 = strongest signal)
- Highlights markets trending toward ≥80% or ≤20% as "Strong Signal"
- Rebuilds and publishes `docs/index.html` automatically every hour

## Setup (5 minutes)

### 1. Create a new GitHub repo

Go to [github.com/new](https://github.com/new), create a **public** repo (e.g. `polymarket-dashboard`). Public is required for free GitHub Pages.

### 2. Push this code

```bash
git init
git add .
git commit -m "initial"
git remote add origin https://github.com/YOUR_USERNAME/polymarket-dashboard.git
git push -u origin main
```

### 3. Enable GitHub Pages

- Go to your repo → **Settings** → **Pages**
- Under **Source**, select **Deploy from a branch**
- Branch: `main`, Folder: `/docs`
- Click **Save**

### 4. That's it!

- GitHub Actions will run `fetch.py` automatically **every hour**
- Your live dashboard will be at: `https://YOUR_USERNAME.github.io/polymarket-dashboard/`
- You can also trigger a manual refresh anytime from the **Actions** tab → **Run workflow**

## Local usage

```bash
python fetch.py          # generates docs/index.html
open docs/index.html     # view in browser
```

No dependencies beyond Python 3.8+ stdlib.

## Files

```
.github/workflows/refresh.yml   # Hourly GitHub Actions job
fetch.py                        # Fetches Polymarket API → builds HTML
docs/index.html                 # Generated dashboard (auto-updated)
```

## Data source

Polymarket Gamma API — fully public, no API key required.  
`https://gamma-api.polymarket.com/markets`
