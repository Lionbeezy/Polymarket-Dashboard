#!/usr/bin/env python3
"""
Fetches live Polymarket data from the Gamma API and generates a static
dashboard HTML file, saved to docs/index.html for GitHub Pages.
"""

import json
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

API_URL = (
    "https://gamma-api.polymarket.com/markets"
    "?active=true&closed=false&limit=50&order=volume24hr&ascending=false"
)

HEADERS = {
    "User-Agent": "polymarket-dashboard/1.0 (github-actions)",
    "Accept": "application/json",
}


def fetch_markets():
    req = urllib.request.Request(API_URL, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read().decode())


def parse_price(market):
    try:
        prices = json.loads(market.get("outcomePrices", "[]"))
        v = float(prices[0])
        if 0 <= v <= 1:
            return v
    except Exception:
        pass
    for key in ("lastTradePrice", "price", "bestBid"):
        try:
            v = float(market.get(key, ""))
            if 0 < v < 1:
                return v
        except Exception:
            pass
    return None


def fmt_vol(v):
    v = v or 0
    if v >= 1_000_000:
        return f"${v/1_000_000:.1f}M"
    if v >= 1_000:
        return f"${v/1_000:.0f}K"
    return f"${v:.0f}"


def certainty(price):
    return abs(price - 0.5)


def build_html(markets, updated_at):
    def card_html(m, i):
        price = m["_price"]
        pct = round(price * 100)
        vol = fmt_vol(m.get("volume24hr", 0))
        liq = fmt_vol(m.get("liquidity", 0))
        q = m.get("question", "Unknown market")

        is_bullish = price >= 0.65
        is_bearish = price <= 0.35
        is_strong = price >= 0.80 or price <= 0.20

        bar_color = (
            "#00ff88" if pct >= 80 else
            "#aaff44" if pct >= 65 else
            "#ff4466" if pct <= 20 else
            "#ff8844" if pct <= 35 else
            "#ffcc00"
        )

        border = (
            f"1px solid {'#00ff8855' if is_bullish else '#ff446655'}"
            if is_strong else "1px solid #ffffff0c"
        )
        glow = (
            f"0 0 18px {'#00ff8810' if is_bullish else '#ff446810'}"
            if is_strong else "none"
        )

        badge = ""
        if is_strong:
            label = "⚡ STRONG YES" if is_bullish else "⚡ STRONG NO"
            color = "#00ff88" if is_bullish else "#ff4466"
            bg = "#00ff8815" if is_bullish else "#ff446615"
            bc = "#00ff8835" if is_bullish else "#ff446635"
            badge = f'<span class="badge" style="color:{color};background:{bg};border:1px solid {bc}">{label}</span>'

        arrow_color = "#00ff88" if is_bullish else "#ff4466" if is_bearish else "#ffcc00"
        arrow = "▲" if is_bullish else "▼" if is_bearish else "◆"

        delay = min(i * 0.03, 0.8)

        return f"""
        <div class="card" style="border:{border};box-shadow:{glow};animation:fadeUp 0.3s ease {delay}s both">
          <div class="card-top">
            <div class="question">{q}</div>
            <div class="price-block">
              <div class="price" style="color:{arrow_color}">{pct}¢</div>
              <div class="arrow" style="color:{arrow_color}">{arrow} {'YES' if is_bullish else 'NO' if is_bearish else '~'}</div>
            </div>
          </div>
          {badge}
          <div class="bar-wrap">
            <div class="bar-labels"><span>YES</span><span style="color:{bar_color};font-weight:700">{pct}%</span><span>NO</span></div>
            <div class="bar-track"><div class="bar-fill" style="width:{pct}%;background:linear-gradient(90deg,{bar_color}55,{bar_color})"></div></div>
          </div>
          <div class="meta">
            <span>24H <b>{vol}</b></span>
            <span>LIQ <b>{liq}</b></span>
          </div>
        </div>"""

    cards = "\n".join(card_html(m, i) for i, m in enumerate(markets))

    total_vol = fmt_vol(sum(m.get("volume24hr", 0) for m in markets))
    strong_count = sum(1 for m in markets if m["_price"] >= 0.8 or m["_price"] <= 0.2)
    avg_cert = round(
        sum(certainty(m["_price"]) for m in markets) / len(markets) * 200
    ) if markets else 0

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Polymarket · Trending Certainty Markets</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&family=Space+Mono:wght@700&display=swap" rel="stylesheet">
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{background:#07071a;color:#e0e0f0;font-family:'Space Mono',monospace;min-height:100vh}}
  @keyframes fadeUp{{from{{opacity:0;transform:translateY(10px)}}to{{opacity:1;transform:translateY(0)}}}}
  ::-webkit-scrollbar{{width:4px}}::-webkit-scrollbar-thumb{{background:#222244;border-radius:2px}}

  .header{{position:sticky;top:0;z-index:10;background:#080820ee;backdrop-filter:blur(10px);border-bottom:1px solid #ffffff08;padding:18px 18px 14px}}
  .header-row{{display:flex;align-items:center;justify-content:space-between}}
  .dot{{width:8px;height:8px;border-radius:50%;background:#00ff88;display:inline-block;margin-right:8px}}
  .label{{font-size:10px;letter-spacing:3px;color:#6366f1;font-weight:700}}
  .title{{font-family:'DM Sans',sans-serif;font-size:20px;font-weight:700;letter-spacing:-0.5px;margin-top:4px}}
  .updated{{font-size:10px;color:#333;margin-top:4px}}

  .stats{{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:14px}}
  .stat{{background:#0d0d20;border:1px solid #ffffff07;border-radius:9px;padding:9px 12px}}
  .stat-label{{font-size:8px;letter-spacing:1.5px;color:#444}}
  .stat-value{{font-family:'DM Sans',sans-serif;font-size:17px;font-weight:700;margin-top:2px}}

  .filters{{display:flex;gap:6px;margin-top:12px;flex-wrap:wrap;align-items:center}}
  .filter-btn{{padding:5px 12px;border-radius:20px;border:1px solid #ffffff0f;background:transparent;color:#555;font-size:11px;font-weight:700;cursor:pointer;font-family:monospace;letter-spacing:0.5px;transition:all .2s}}
  .filter-btn.active{{border-color:#6366f188;background:#6366f118;color:#a5b4fc}}

  .cards{{padding:14px 14px 40px;display:flex;flex-direction:column;gap:9px}}
  .card{{background:#0c0c1d;border-radius:12px;padding:15px 16px;position:relative}}
  .card-top{{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:8px}}
  .question{{font-family:'DM Sans',sans-serif;font-size:13px;font-weight:600;line-height:1.45;color:#dde;flex:1}}
  .price-block{{text-align:right;flex-shrink:0}}
  .price{{font-family:'DM Sans',sans-serif;font-size:22px;font-weight:700;line-height:1}}
  .arrow{{font-size:10px;margin-top:3px}}
  .badge{{display:inline-block;font-size:9px;font-weight:700;letter-spacing:1.5px;padding:2px 8px;border-radius:10px;margin-bottom:8px}}
  .bar-wrap{{margin-top:6px}}
  .bar-labels{{display:flex;justify-content:space-between;font-size:11px;color:#777;margin-bottom:4px;font-family:monospace}}
  .bar-track{{height:5px;background:#1a1a2e;border-radius:3px;overflow:hidden}}
  .bar-fill{{height:100%;border-radius:3px;transition:width .6s}}
  .meta{{display:flex;gap:14px;margin-top:10px;font-size:10px;color:#444;font-family:monospace}}
  .meta b{{color:#888}}

  .footer{{margin:0 14px 20px;padding:12px 14px;background:#0d0d20;border-radius:10px;border:1px solid #ffffff07;font-size:10px;color:#333;line-height:1.8}}

  @media(max-width:480px){{
    .stats{{grid-template-columns:repeat(3,1fr)}}
    .stat-value{{font-size:14px}}
    .price{{font-size:18px}}
  }}
</style>
</head>
<body>

<div class="header">
  <div class="header-row">
    <div>
      <div><span class="dot"></span><span class="label">POLYMARKET</span></div>
      <div class="title">Trending Certainty Markets</div>
    </div>
    <div style="text-align:right">
      <div style="font-size:9px;color:#333">AUTO-REFRESHED</div>
      <div style="font-size:10px;color:#555;margin-top:2px">Every hour via GitHub Actions</div>
    </div>
  </div>
  <div class="updated">Last fetched: {updated_at} UTC · {len(markets)} markets</div>

  <div class="stats">
    <div class="stat"><div class="stat-label">24H VOLUME</div><div class="stat-value" style="color:#a5b4fc">{total_vol}</div></div>
    <div class="stat"><div class="stat-label">STRONG SIGNAL</div><div class="stat-value" style="color:#fbbf24">{strong_count}</div></div>
    <div class="stat"><div class="stat-label">AVG CERTAINTY</div><div class="stat-value" style="color:#34d399">{avg_cert}%</div></div>
  </div>

  <div class="filters">
    <button class="filter-btn active" onclick="filterCards(this,'all')">ALL ({len(markets)})</button>
    <button class="filter-btn" onclick="filterCards(this,'bullish')">▲ YES≥65%</button>
    <button class="filter-btn" onclick="filterCards(this,'bearish')">▼ NO≥65%</button>
    <button class="filter-btn" onclick="filterCards(this,'strong')">⚡ ≥80%</button>
    <button class="filter-btn" style="margin-left:auto" onclick="sortCards(this,'certainty')">CERTAINTY</button>
    <button class="filter-btn" onclick="sortCards(this,'volume')">VOLUME</button>
  </div>
</div>

<div class="cards" id="cards">{cards}</div>

<div class="footer">
  📡 Data: Polymarket Gamma API · Refreshed hourly via GitHub Actions · Hosted on GitHub Pages<br>
  Prices show YES probability (0–100¢). Sorted by directional certainty (furthest from 50/50 first).
</div>

<script>
  // Embed market data for client-side filtering/sorting
  const DATA = {json.dumps([
      {
          "question": m.get("question",""),
          "price": m["_price"],
          "vol": m.get("volume24hr", 0),
          "liq": m.get("liquidity", 0),
      }
      for m in markets
  ])};

  let currentFilter = 'all';
  let currentSort = 'certainty';

  function filterCards(btn, f) {{
    currentFilter = f;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    render();
  }}

  function sortCards(btn, s) {{
    currentSort = s;
    render();
  }}

  function fmt(v) {{
    if (v >= 1e6) return '$' + (v/1e6).toFixed(1) + 'M';
    if (v >= 1e3) return '$' + (v/1e3).toFixed(0) + 'K';
    return '$' + Math.round(v);
  }}

  function render() {{
    let d = DATA.filter(m => {{
      if (currentFilter === 'bullish') return m.price >= 0.65;
      if (currentFilter === 'bearish') return m.price <= 0.35;
      if (currentFilter === 'strong') return m.price >= 0.8 || m.price <= 0.2;
      return true;
    }});
    if (currentSort === 'volume') d.sort((a,b) => b.vol - a.vol);
    else d.sort((a,b) => Math.abs(b.price-0.5) - Math.abs(a.price-0.5));

    const container = document.getElementById('cards');
    container.innerHTML = d.map((m,i) => {{
      const pct = Math.round(m.price*100);
      const isBull = m.price>=0.65, isBear = m.price<=0.35, isStrong = m.price>=0.8||m.price<=0.2;
      const c = pct>=80?'#00ff88':pct>=65?'#aaff44':pct<=20?'#ff4466':pct<=35?'#ff8844':'#ffcc00';
      const border = isStrong ? `1px solid ${{isBull?'#00ff8855':'#ff446655'}}` : '1px solid #ffffff0c';
      const glow = isStrong ? `0 0 18px ${{isBull?'#00ff8810':'#ff446810'}}` : 'none';
      const ac = isBull?'#00ff88':isBear?'#ff4466':'#ffcc00';
      const arrow = isBull?'▲':isBear?'▼':'◆';
      const badge = isStrong ? `<span class="badge" style="color:${{isBull?'#00ff88':'#ff4466'}};background:${{isBull?'#00ff8815':'#ff446615'}};border:1px solid ${{isBull?'#00ff8835':'#ff446635'}}">⚡ ${{isBull?'STRONG YES':'STRONG NO'}}</span>` : '';
      return `<div class="card" style="border:${{border}};box-shadow:${{glow}};animation:fadeUp 0.25s ease ${{Math.min(i*0.03,0.6)}}s both">
        <div class="card-top">
          <div class="question">${{m.question}}</div>
          <div class="price-block"><div class="price" style="color:${{ac}}">${{pct}}¢</div><div class="arrow" style="color:${{ac}}">${{arrow}} ${{isBull?'YES':isBear?'NO':'~'}}</div></div>
        </div>
        ${{badge}}
        <div class="bar-wrap">
          <div class="bar-labels"><span>YES</span><span style="color:${{c}};font-weight:700">${{pct}}%</span><span>NO</span></div>
          <div class="bar-track"><div class="bar-fill" style="width:${{pct}}%;background:linear-gradient(90deg,${{c}}55,${{c}})"></div></div>
        </div>
        <div class="meta"><span>24H <b>${{fmt(m.vol)}}</b></span><span>LIQ <b>${{fmt(m.liq)}}</b></span></div>
      </div>`;
    }}).join('');
  }}
</script>
</body>
</html>"""


def main():
    print("Fetching Polymarket data...")
    raw = fetch_markets()
    print(f"Got {len(raw)} markets from API")

    markets = []
    for m in raw:
        price = parse_price(m)
        if price is not None and m.get("volume24hr", 0) > 500:
            markets.append({**m, "_price": price})

    # Sort by certainty (furthest from 50%)
    markets.sort(key=lambda m: abs(m["_price"] - 0.5), reverse=True)
    print(f"Kept {len(markets)} markets with valid prices")

    updated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
    html = build_html(markets, updated_at)

    out = Path("docs/index.html")
    out.parent.mkdir(exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"Written to {out} ({len(html):,} bytes)")


if __name__ == "__main__":
    main()
